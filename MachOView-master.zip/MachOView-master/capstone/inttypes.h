#if defined(_MSC_VER) && _MSC_VER <= 1700
#include "msvc/headers/inttypes.h"
#else
#include <inttypes.h>
#endif
